import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './gaurds/auth.guard';
import { ForgetPasswordComponent } from './login-com/forget-password/forget-password.component';
import { LoginComponent } from './login-com/login/login.component';
import { NotFoundComponent } from './login-com/not-found/not-found.component';

const routes: Routes = [
  { path:'', component: LoginComponent },
  { path: 'forget-password', component: ForgetPasswordComponent},
  { path: '', redirectTo: '/login', pathMatch: 'full'},
  {
    path: 'admin', 
    canActivate: [AuthGuard],
    loadChildren: () => 
      import('./modules/admin/admin.module').then((m) => m.AdminModule)
  },
  { path: '**', component: NotFoundComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
